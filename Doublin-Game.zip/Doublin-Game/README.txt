Thanks for downloading Doublin! We had a lot of fun making it, and we hope you'll have a good time playing it. There are three levels: two tutorial levels + an endless arena level. This was made as a proof of concept and should be played as such. 

To run the game, run the typing_prototype.exe file.

View the source code here: https://github.com/BrendanHoagie/TypingGamePrototype
View the website here: https://brendanhoagie.github.io/Doublin-Website/#

Controls:
Player 1
-move with arrow keys
-aim with mouse
-left click to attempt to cast a spell
-right click to cancel current spell attempt
-all other alphanumeric keys to type a spell
-relay information to player 2 about enemy wizards

Player 2
-using information about enemy wizards, navigate the grimoire to find weaknesses
-relevant information includes their robe color and their hat color
-relay correct incantations to player 1